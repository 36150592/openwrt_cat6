int builtInVendorIds[] = {
    0x18d1, /* Google */
    0x0bb4, /* HTC */
    0x04e8, /* Samsung */
    0x22b8, /* Motorola */
    0x1004, /* LG */
    0x12D1, /* Huawei */
    0x0502, /* Acer */
    0x0FCE, /* Sony Ericsson */
    0x0489, /* Foxconn */
    0x413c, /* Dell */
    0x0955, /* Nvidia */
    0x091E, /* Garmin-Asus */
    0x04dd, /* Sharp */
    0x19D2, /* ZTE */
    0x0482, /* Kyocera */
    0x10A9, /* Pantech */
    0x05c6, /* Qualcomm */
    0x2257, /* On-The-Go-Video */
    0x0409, /* NEC */
    0x04DA, /* Panasonic Mobile Communication */
    0x0930, /* Toshiba */
    0x1F53, /* SK Telesys */
    0x2116, /* KT Tech */
    0x0b05, /* Asus */
    0x0471, /* Philips */
    0x0451, /* Texas Instruments */
    0x0F1C, /* Funai */
    0x0414, /* Gigabyte */
    0x2420, /* IRiver */
    0x1219, /* Compal */
    0x1BBB, /* T & A Mobile Phones */
    0x2006, /* LenovoMobile */
    0x17EF, /* Lenovo */
    0xE040, /* Vizio */
    0x24E3, /* K-Touch */
    0x1D4D, /* Pegatron */
    0x0E79, /* Archos */
    0x1662, /* Positivo */
    0x15eb, /* VIA-Telecom */
    0x04c5, /* Fujitsu */
    0x091e, /* GarminAsus */
    0x109b, /* Hisense */
    0x24e3, /* KTouch */
    0x17ef, /* Lenovo */
    0x2080, /* Nook */
    0x10a9, /* Pantech */
    0x1d4d, /* Pegatron */
    0x04da, /* PMCSierra */
    0x1f53, /* SKTelesys */
    0x054c, /* Sony */
    0x0fce, /* SonyEricsson */
    0x2340, /* Teleepoch */
    0x19d2, /* ZTE */
    0x201e, /* Haier */
    /* TODO: APPEND YOUR ID HERE! */
};
